#include "SortedAddressLinkList.h"

SortedAddressLinkList::SortedAddressLinkList()
{
	head = nullptr;
	pos = nullptr;
	size = 0;
}

SortedAddressLinkList::~SortedAddressLinkList()
{
	makeEmpty();
}

void SortedAddressLinkList::putItem(string)
{
}

void SortedAddressLinkList::deleteItem(string)
{
}

void SortedAddressLinkList::makeEmpty()
{
}

bool SortedAddressLinkList::listFull()
{
	return false;
}

int SortedAddressLinkList::getLength()
{
	return 0;
}

void SortedAddressLinkList::resetList()
{
}

int SortedAddressLinkList::getNextItem()
{
	return 0;
}

void SortedAddressLinkList::displayList()
{
}

bool SortedAddressLinkList::findItem(string)
{
	return false;
}

int SortedAddressLinkList::getItem()
{
	return 0;
}

int SortedAddressLinkList::getItem(string)
{
	return 0;
}
